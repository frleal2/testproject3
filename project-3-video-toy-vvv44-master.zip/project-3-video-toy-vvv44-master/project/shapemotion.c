/** \file shapemotion.c
 *  \brief This is a simple shape motion demo.
 *  This demo creates two layers containing shapes.
 *  One layer contains a rectangle and the other a circle.
 *  While the CPU is running the green LED is on, and
 *  when the screen does not need to be redrawn the CPU
 *  is turned off along with the green LED.
 */  
#include <msp430.h>
#include <libTimer.h>
#include <lcdutils.h>
#include <lcddraw.h>
#include <shape.h>
#include <abCircle.h>
#include "pac_shape.h"
#include <chordVec.h>
#include "switches.h"
#include "movementB.h"
#include <stdlib.h>
#include "buzzer.h"
#include "scorer.h"
#include "cheater.h"

#define GREEN_LED BIT6


Pac_Man pacman = {abCircleGetBounds, pac_man_check, chordVec10, 10}; //pacman shape based on circle 10
AbCircle food2 = {abCircleGetBounds, abCircleCheck, chordVec2, 2}; //red dots for feeding pacman
AbCircle food1 = {abCircleGetBounds, abCircleCheck, chordVec2, 2};
AbCircle food0 = {abCircleGetBounds, abCircleCheck, chordVec2, 2};


AbRectOutline fieldOutline = {	/* playing field */
  abRectOutlineGetBounds, abRectOutlineCheck,   
  {screenWidth/2 - 10, screenHeight/2 - 10}
};


Layer fieldLayer = {		/* playing field as a layer */
  (AbShape *) &fieldOutline,
  {screenWidth/2, screenHeight/2},/**< center */
  {0,0}, {0,0},				    /* last & next pos */
  COLOR_BLACK,
  0
};

Layer layer3 = { /*Layer with a pacman*/
  (AbShape *)&pacman,
  {+40,screenHeight-20}, /*bottom left corner*/
  {0,0},{0,0},  /*last and next position*/
  COLOR_YELLOW,
  &fieldLayer
};
/*A layer with a small ball shape for testing purposes*/
Layer layer2 = {
  (AbShape *)&food2,
  {+20,+15}, /*top left corner*/
  {0,0}, {0,0},
  COLOR_RED,
  &fieldLayer,
};
/*More balls to act as food*/
Layer layer1 = {
  (AbShape *)&food1,
  {+40,+15}, /*to the right of the other ball*/
  {0,0},{0,0},
  COLOR_RED,
  &layer2,
};
/*Another ball as food*/
Layer layer0 = {
  (AbShape *) &food0,
  {+60, +15},
  {0,0},{0,0},
  COLOR_RED,
  &layer1,
};
/* initial value of {0,0} will be overwritten */
MovLayer ml3 = { &layer3, {0,0}, 0 }; /**Pacman moves horizontally only*/
MovLayer ml2 = { &layer2, {0,3}, 0 }; //vertical movement only
MovLayer ml1 = { &layer1, {0,6}, &ml2};
MovLayer ml0 = { &layer0, {0,2}, &ml1};
//Region fence = {{10,30}, {SHORT_EDGE_PIXELS-10, LONG_EDGE_PIXELS-10}}; /**< Create a fence region */



u_int bgColor = COLOR_BLUE;     /**< The background color */
int redrawScreen = 1;           /**< Boolean for whether screen needs to be redrawn */

Region fieldFence;		/**< fence around playing field  */

/*Ends game and restores it to initial settings*/
void restoreGame(MovLayer *mlP){
  score = 0; //reset score
  mlP = &ml0;
  char i = 1;
  for(;mlP;mlP = mlP->next){ //restores original positions of food
    mlP->layer->pos.axes[0] = i*20;
    mlP->layer->pos.axes[1] = 20;
    i++;
  }
  layer3.pos.axes[0] = +40; //restores original position of pacman
  layer3.pos.axes[1] = screenHeight-20;
  layerInit(&layer0);//reinitialize and draw stuff
  layerDraw(&layer0);
  layerInit(&layer3);
  layerDraw(&layer3);
}

/** Initializes everything, enables interrupts and green LED, 
 *  and handles the rendering for the screen
 */
void main()
{
  P1DIR |= GREEN_LED;		/**< Green led on when CPU on */		
  P1OUT |= GREEN_LED;

  buzzer_init();
  configureClocks();
  lcd_init();
  shapeInit();
  switch_init();
  shapeInit();
  layerInit(&layer0);
  layerDraw(&layer0);
  layerInit(&layer3);
  layerDraw(&layer3);

  layerGetBounds(&fieldLayer, &fieldFence);
    
  enableWDTInterrupts();      /**< enable periodic interrupt */
  or_sr(0x8);	              /**< GIE (enable interrupts) */


  for(;;) { 
    while (!redrawScreen) { /**< Pause CPU if screen doesn't need updating */
      P1OUT &= ~GREEN_LED;    /**< Green led off witHo CPU */
      or_sr(0x10);	      /**< CPU OFF */
    }
    P1OUT |= GREEN_LED;       /**< Green led on when CPU on */
    redrawScreen = 0;
    movLayerDraw(&ml0, &layer0);//redraw necessary layers
    movLayerDraw(&ml3, &layer3);
    scoreUp(); //update score
    if(score == 20) restoreGame(&ml0); //resets game to beginning
    drawString5x7(screenWidth-80,0, "Score", COLOR_RED, COLOR_BLUE);
  }
}

/** Watchdog timer interrupt handler. 15 interrupts/sec */
void wdt_c_handler()
{
  static short count = 0;
  P1OUT |= GREEN_LED;		      /**< Green LED on when cpu on */
  count ++;
  if ((count == 15) && !(cheatOn)) {
    mlAdvanceSh(&ml0,&fieldFence, &ml3);
    redrawScreen = 1;
    count = 0;
  }
  if(count>15) count = 0; //in case cheat mode is on
  P1OUT &= ~GREEN_LED;		    /**< Green LED off when cpu off */
}

/*Interrupt handler for our switches*/
void __interrupt_vec(PORT2_VECTOR) Port_2(){
  if(P2IFG & SWITCHES){
    P2IFG &= ~SWITCHES;
    switch_interrupt_handler(&ml3, &fieldFence); //we give it the parameters to invoque movement
    redrawScreen = 1;
  }
}
