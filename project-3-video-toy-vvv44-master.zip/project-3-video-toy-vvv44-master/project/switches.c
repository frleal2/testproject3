#include <msp430.h>
#include "movementB.h"
#include "switches.h"
#include <shape.h>
#include "buzzer.h"
#include "cheater.h"

extern void toggleCheat(); //declaration of function from assembly
extern short cheatState;

static char 
switch_update_interrupt_sense()
{
  char p2val = P2IN;
  /* update switch interrupt to detect changes from current buttons */
  P2IES |= (p2val & SWITCHES);	/* if switch up, sense down */
  P2IES &= (p2val | ~SWITCHES);	/* if switch down, sense up */
  return p2val;
}

void 
switch_init()			/* setup switch */
{  
  P2REN |= SWITCHES;		/* enables resistors for switches */
  P2IE = SWITCHES;		/* enable interrupts from switches */
  P2OUT |= SWITCHES;		/* pull-ups for switches */
  P2DIR &= ~SWITCHES;		/* set switches' bits for input */
  switch_update_interrupt_sense();
}

void
switch_interrupt_handler(MovLayer *ml,Region *fence)
{
  char p2val = switch_update_interrupt_sense();
  char vel;
  if(!(p2val & SW1)){
    vel = 6;
    ml->velocity.axes[0] = vel;
    mlAdvance(ml, fence); //advance figure given
    ml->velocity.axes[0] = 0;
  }
  if(!(p2val & SW0)){
    vel = 6;
    ml->velocity.axes[0] = vel;
    mlAdvanceOpp(ml,fence);
    ml->velocity.axes[0] = 0;
  }
  if(!(p2val & SW2)){
    if(cheatState == 0){
      cheatState = 1;
      toggleCheat();
    }else{
      cheatState = 0;
      toggleCheat();
    }
  }
  if(!(p2val & SW3)){
    //you can keep trying to press fourth button, your ex still won't come back
  }

  
}
