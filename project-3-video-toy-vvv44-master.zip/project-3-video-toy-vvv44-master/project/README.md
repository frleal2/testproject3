Project Summary:
  
  I decided to go for a very simple game, a pacman-like figure on the bottom, moves horizontally to try and catch little dots that fall from the sky
the objective is to get 20 points, when the figure "eats" the dots, these go back to their original vertical position but change their horizontal one, to fall again. When the figure "eats"
or bounces off a wall, a sound is produced. The project uses 3 switches, the lcd, a custom shape, generates movement, sound, and makes use of a state machine
written in assembly along with displaying an updating score with text in screen.


Game Instructions:

  Movement: Buttons one and two (from left to right) are used to move left or right (respectively).
  Limiters: The rectangle area is the place where everything is, any attempts to move the character out of such area will result in 
  it "bumping" back, and the game alerting with a sound.
  Objective: Eating 20 of the red dots (think of them as apples, or the blood of your enemies, if you prefer...), simple. However, dots fall
  at different speeds and change horizontal position. When objective is reached, game resets score, position and everything begins again.
  
  P.D. If you feel like the game is too hard (which is something to feel bad about, given how easy the game is) you can press the third button
  (to the right of the one you use to move to the right) and that will freeze the red dots, so you can confortably move your character
  below one of the dots and eat it, piece of cake.
