#include "scorer.h"
#include <lcdtypes.h>
#include <lcddraw.h>
#include <lcdutils.h>
#include <stdlib.h>
#include <shape.h>

char buffer[5]; //buffer for converting int to string
int score = 0; //initial score
char scoreChanged = 0; //0 if did not change, 1 if it did

/**Method to update score
*/
void scoreUp(){
  if(scoreChanged){
    //we update the score value and reset variable of scoreChanged
    score++;
    itoa(score,buffer,10); //convert to string
    drawString5x7(screenWidth-40, 0, buffer, COLOR_RED, COLOR_BLUE);
    scoreChanged = 0; //reset notice of score changing
  }
  //otherwise we draw current score
  itoa(score,buffer,10);
  drawString5x7(screenWidth-40, 0 , buffer, COLOR_RED, COLOR_BLUE);
}
