#ifndef scorer_defined
#define scorer_defined


extern char scoreChanged; //external variable to make score change
extern int score;

void scoreUp(); //method to update score

#endif
