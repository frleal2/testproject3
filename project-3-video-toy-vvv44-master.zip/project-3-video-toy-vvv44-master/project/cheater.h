#ifndef cheater_included
#define cheater_included


extern char cheatOn; //variale that will tell us if cheat mode is on

void toggleCheat(); //method to turn cheat mode on


#endif
