# p2swLib from Project 3: LCD Game
## Introduction

p2swLib provides a framework for initializing and reading the switches on P2. 


## Demo code

switchdemo.c is a program that sets the red LED to be on. When the switch S1, on P2, is down the red LED is turned off. 


## Installing the p2sw lib (for other programs)

$ make install

