#ifndef libTimer_included
#define libTimer_included

#include "clocksTimer.h"
#include "sr.h"

#endif // included
